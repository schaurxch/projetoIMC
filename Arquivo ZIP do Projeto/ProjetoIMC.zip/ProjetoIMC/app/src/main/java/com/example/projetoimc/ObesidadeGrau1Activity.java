package com.example.projetoimc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ObesidadeGrau1Activity extends AppCompatActivity {

    private TextView textIMCResult;
    private Button btnClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_obesidade_grau1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnClose = findViewById(R.id.btnClose);
        textIMCResult = findViewById(R.id.textIMCResult);

        Bundle bundle = getIntent().getExtras();

        double weight = bundle.getDouble("weight");
        double height = bundle.getDouble("height");
        double imc = weight / (height * height); // Calculate IMC here

        String result = "Altura: " + height + " m" + "\n" +
                "Peso: " + weight + " kg" + "\n" +
                "IMC: " + String.format("%.2f", imc);        textIMCResult.setText(result);

        btnClose.setOnClickListener(view -> {

            Intent intent = new Intent(ObesidadeGrau1Activity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Clear top activities
            startActivity(intent);
            finish(); // Close the current activity

        });
    }
}